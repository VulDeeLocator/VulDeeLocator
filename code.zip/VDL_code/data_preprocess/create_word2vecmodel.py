## coding: utf-8
'''
该python文件用于根据语料库训练学习词向量，再将生成的词向量模型保存在w2v_model下。
This python file is used to tranfer the words in corpus to vector, and save the word2vec model under the path 'w2v_model'.
================================================================
代码修改：Yoki
语言：Python 3.6
编写时间：2018.07.09

coder: Yoki
Language: Python 3.6
Date: 2018.07.09
================================================================
Log
-------------------------------------
* 2017.12.22  Yoki
modify the original python file to adapt the new slices
* 2017.12.23  Yoki
use the gensim 3.2.0 to fix the warn can not use C compile
使用gensim 3.2.0以修复无法使用C编译加速训练的问题
注意：本python文件中使用gensim的3.2.0版本，使用pip进行install，使用的并非当前路径下的gensim文件夹
* 2018.01.05  Yoki
Modify to adapt big data
为了适应大数据量，尝试通过yield逐步生成待训练语句
* 2018.01.10  Yoki
change pickle into cPickle
* 2018.07.09  Yoki
change to adapt python3.6
'''

from __future__ import print_function
from gensim.models import Word2Vec
import pickle
import os
import gc
import os

os.environ['PYTHONHASHSEED'] = "2018"   #用于实验重现

#读取有效的testcase_id
testcases = []
f = open("record/testcases_train2.pkl",'rb')
testcases += pickle.load(f)
f.close()
f = open("record/testcases_test2.pkl",'rb')
testcases += pickle.load(f)
f.close()


'''
DirofCorpus class
-----------------------------
形成待训练的语句生成器
This class is used to make a generator to produce sentence for word2vec training

# Arguments
    dirname: The src of corpus files 语句库文件保存的路径
    
'''
class DirofCorpus(object):   #语句生成器
    def __init__(self, dirname):
        self.dirname = dirname
        self.iter_num = 0
    
    def __iter__(self):
        print("\nepoch: ", self.iter_num)
        for d in self.dirname:
            for fn in os.listdir(d):
                '''
                if not fn in testcases:
                    #如果不是被命运选中的testcase
                    continue
                '''
                print("\r"+fn, end='')
                for filename in os.listdir(os.path.join(d, fn)):
                    sample = pickle.load(open(os.path.join(d, fn, filename), 'rb'))[0]
                    yield sample
                    
        self.iter_num += 1

'''
generate_w2vmodel function
-----------------------------
训练生成的词向量，并保存训练得到的模型
This function is used to learning vectors from corpus, and save the model

# Arguments
    decTokenFlawPath: String type, the src of corpus file 语料保存的路径
    w2vModelPath: String type, the src of model file 训练好的词向量模型路径
    
'''
def generate_w2vModel(decTokenFlawPath, w2vModelPath, size=30, alpha=0.008, window=5, min_alpha=0.0005, sg=1, hs=0, negative=7, iter=3):
    print("training...")
    model = Word2Vec(sentences= DirofCorpus(decTokenFlawPath), size=size, alpha=alpha, window=window, min_count=1, max_vocab_size=None, sample=0.001, seed=1, workers=1, min_alpha=min_alpha, sg=sg, hs=hs, negative=negative, iter=iter)
    model.save(w2vModelPath)
    #size指词向量的维度，window表示扫描上下文窗口的大小（前5个词和后5个词）， alpha: 是学习速率，min_count表示忽略出现次数少于1次的词，max_vocab_size设置词向量构建期间的RAM限制,None表示没有限制。
    #sample: 高频词汇的随机降采样的配置阈值，seed用于随机数发生器,与初始化词向量有关。
    #workers:参数控制训练的并行数, iter： 迭代次数,negative: 如果>0,则会采用negativesamp·ing，用于设置多少个noise words.
    #sg: 用于设置训练算法，默认为0，对应CBOW算法；sg=1则采用skip-gram算法。
    #hs:如果为1则会采用hierarchica·softmax技巧。如果设置为0（defau·t），则negative sampling会被使用。
    
'''
evaluate_w2vmodel function
-----------------------------
读取训练得到的模型用于评估
This function is used to load model and evaluate it.

# Arguments
    w2vModelPath: String type, the src of model file 训练好的词向量模型路径
    
'''
def evaluate_w2vModel(w2vModelPath):  #评估训练得到的word2vec模型
    print("\nevaluating...")
    model = Word2Vec.load(w2vModelPath)
    for sign in ['(', 'icmp', 'func_0', 'i32', '%2']:
        print(sign, ":")
        print(model.most_similar_cosmul(positive=[sign], topn=10))
    

'''#更新词向量，并训练新的模型
def update_w2vModel(newTokenPath, modelPath, newModelPath):
    #更新词向量
    #newTokenPath是新投入训练的数据路径, modelPath是原始模型保存路径, newModelPath是新的模型保存路径
    model = Word2Vec.load(modelPath)
    
    for folder in os.listdir(newTokenPath):
        print("\r"+folder, end='')
        for filename in os.listdir(os.path.join(newTokenPath, folder)):
            f1 = open(os.path.join(newTokenPath, folder, filename), 'rb')
            sentences = pickle.load(f1)[0]
            f1.close()
            model.build_vocab([sentences], update=True)
            model.train([sentences], total_examples=model.corpus_count, epochs=model.iter)
    model.save(newModelPath)
    print("\nsuccess!")
    '''

#统计计算切片长度
def get_timesteps_values(decTokenFlawPath, threShold):
    #根据阈值计算前threshold%的数据流长度是多少
    lengths = []
    for path in decTokenFlawPath:
        for testcase in os.listdir(path):
            for filename in os.listdir(os.path.join(path, testcase)):
                f1 = open(os.path.join(path, testcase, filename), 'rb')
                lengths.append(len(pickle.load(f1)[0]))
                f1.close()

    lengths = sorted(lengths)
    len_list = len(lengths)

    index = int(len_list * threShold)
    print(index)
    print(lengths[index])
    

def main():
    #语料库路径
    dec_tokenFlaw_path = ['./data/corpus_SARD+NVD/']
    
    #get_timesteps_values(dec_tokenFlaw_path, 0.95)
    
    '''#用于更新词库
    newTokenPath = './data/SARD/corpus_test_0818/'
    modelPath = "w2v_model/wordmodel_iter10.model"
    newModelPath = "w2v_model/wordmodel_iter10_add0818.model"
    update_w2vModel(newTokenPath, modelPath, newModelPath)
    return
    '''
    #训练模型
    for iter in [3, 5, 10, 15]:
        #word2vec模型保存路径
        w2v_model_path = "w2v_model/wordmodel_min_iter"+str(iter)+".model"
        '''
        generate_w2vModel(dec_tokenFlaw_path, w2v_model_path, iter=iter)
        '''
    
        #评估模型
        evaluate_w2vModel(w2v_model_path)
    

 
   
if __name__ == "__main__":
    main()


