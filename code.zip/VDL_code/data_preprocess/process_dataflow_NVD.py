## coding: utf-8
'''
该python文件用于对漏洞切片进行预处理，包括对漏洞切片pkl文件进行读取、分割以及源码分词，以形成用于word2vec或doc2vec训练需要的词库文件。
正常运行main函数产生的结果为在CORPUSPATH路径下产生对应的同文件名词库pkl文件。重新执行main函数时需要清空./data/corpus文件夹下保存的语料库。
This python file is used to precess the vulnerability slices, including read the pkl file and split codes into corpus.
Run main function and you can get a corpus pkl file which map the same name slice file.
================================================================
原始文件：SySeVR/data_preprocess/process_dataflow.py
代码编写：Yoki
语言：Python 3.6
编写时间：2018.06.14

Original file: BLSTM/data_preprocess/process_dataflow.py    BLSTM/data_preprocess/generator_w2v_corpus.py
coder: Yoki
Language: Python 3.6
Date: 2018.06.14
================================================================
Log
-------------------------------------
* 2018.06.14  Yoki
modify the original python file to adapt the new slices
* 2018.07.03  Yoki
modify to adapt LLVM
'''
from __future__ import print_function
from get_tokens import *
import os  #os模块提供了一个统一的操作系统接口函数，这些接口函数通常是平台指定的，os模块能在不同操作系统平台如nt或posix中的特定函数间自动切换，从而能实现跨平台操作
import stat
import pickle  #使用pickle模块将数据保存到.pkl文件（.pkl文件中存储序列化的数据）

#读取有效的testcase_id
testcases = []

f = open("record/all_testcases_train.pkl",'rb')  #读取训练程序
testcases += pickle.load(f)  #pickle(f)表示从文件f中读取一个字符串
f.close()

#'''
f = open("record/all_testcases_test.pkl",'rb')
testcases += pickle.load(f)
f.close()
#'''

def get_sentences(slicepath, labelpath, corpuspath):
    """split sentences into corpus
    将切片文件中的LLVM转换为单个词汇以组成词库
    
    This function is used to split the slice file and split codes into words

    # Arguments
        slicepath: String type, the src of slice files		// 切片文件路径
        labelpath: String type, the src of label files  // 切片对应的标签文件路径
        corpuspath: String type, the src to save corpus // 保存语料库的文件路径

    # Return
        [slices[], linenum[], vlinenum[]]        // 返回切片、每一行起始token的索引值以及漏洞点索引值
    """

    #分别读取每一个切片文件
    for folder in os.listdir(slicepath):    #返回data_source中的文件  
        filepath = os.path.join(labelpath, folder+"_Flawline.pkl")			
        f = open(filepath, 'rb')
        labellists = pickle.load(f)  #读取标签存放在labellists中
        f.close()
        #print(labellists)
        
        #处理标签文件的路径，便于查找漏洞行
        temp_labellists = {}
        for key in labellists.keys():
            temp_labellists["/".join(key.split("/")[-5:])] = labellists[key]
        labellists = temp_labellists

        #os.listdir(path)函数读取每一个testcase__LLVM切片文件夹，os.path,join()函数将多个路径组合后返回
        for category_1 in os.listdir(os.path.join(slicepath, folder)):
            for category_2 in os.listdir(os.path.join(slicepath, folder, category_1)):
                for category_3 in os.listdir(os.path.join(slicepath, folder, category_1, category_2)):
                    if not os.path.isdir(os.path.join(slicepath, folder, category_1, category_2, category_3)):
                        continue  #os.path.isdir(path)函数判断该路径是否为目录
                    #if not testcase_1+testcase_2+testcase_3 in testcases:
                        #如果不是被命运选中的testcase则跳过
                        #continue
                    for fourfocus in os.listdir(os.path.join(slicepath, folder, category_1, category_2, category_3)):
                        if os.path.isdir(os.path.join(slicepath, folder, category_1, category_2, category_3, fourfocus)):
                            for filename in os.listdir(os.path.join(slicepath, folder, category_1, category_2, category_3, fourfocus)):
                                if filename.endswith(".final.ll"):#对于LLVM，切片数据格式为.final.ll后缀的文本文件
                                    print("\r"+category_1+category_2+category_3,end='')

                                    #读取切片文件
                                    filepath = os.path.join(slicepath, folder, category_1, category_2, category_3, fourfocus, filename)
                                    if os.path.getsize(filepath) > 1:
						
                                        f = open(filepath, 'r')
                                        sentences = f.read().split("\n") #读取切片文件并按行进行拆分
                                        f.close()

                                        #找出该切片对应的漏洞行，标签文件中的漏洞行是自1开始记或为空列表；找不到漏洞行则testcase无效
                                        if "/".join([category_1, category_2, category_3, fourfocus, filename]) in labellists:
                                            vlinenumlists = labellists["/".join([category_1, category_2, category_3, fourfocus, filename])]
                                        else:
                                            continue
                                    
                                        #预备处理切片
                                        slice_corpus = []
                                        slice_linenum = []
                                        slice_vlinenum = []
                                        slice_func = []
                                        token_index = 0
                                        linenum_index = 0
                                        funcs = []
                                        variables = []
                                        #切片首行尾行无效数据处理
                                        if sentences[0] == '\r' or sentences[0] == '':
                                            del sentences[0]
                                        if sentences == []:
                                            continue
                                        if sentences[-1] == '' or sentences[-1] == '\r':
                                            del sentences[-1]

                                        #对于单个样本的每一行删除语句行号，并进行分词
                                        for sentence in sentences:
                                            
                                            list_tokens = create_tokens(sentence.strip())   #分词
                                        
                                            #自定义函数名映射、变量名映射
                                            for t_index in range(1,len(list_tokens)):
                                                if list_tokens[t_index].startswith("@"):
                                                    #自定义的程序内调用函数，上一行call下一行define
                                                    if (list_tokens[0] == "call" and "define" in sentences[sentences.index(sentence)+1]) or (list_tokens[0] == "define" and "call" in sentences[sentences.index(sentence)-1]):
                                                        #函数名记录
                                                        if "good" in list_tokens[t_index] or "bad" in list_tokens[t_index]:
                                                            slice_func.append(str(list_tokens[t_index]))
                                                        #函数名映射
                                                        if list_tokens[t_index] in funcs:
                                                            list_tokens[t_index] = "func_"+str(funcs.index(list_tokens[t_index]))
                                                        else:
                                                            funcs.append(list_tokens[t_index])
                                                            list_tokens[t_index] = "func_"+str(len(funcs)-1)
                                                    elif list_tokens[0] == "define" or list_tokens[0] == "store":
                                                        #函数名记录
                                                        if "good" in list_tokens[t_index] or "bad" in list_tokens[t_index]:
                                                            slice_func.append(str(list_tokens[t_index]))
                                                        #函数名映射
                                                        if list_tokens[t_index] in funcs:
                                                            list_tokens[t_index] = "func_"+str(funcs.index(list_tokens[t_index]))
                                                        else:
                                                            funcs.append(list_tokens[t_index])
                                                            list_tokens[t_index] = "func_"+str(len(funcs)-1)
                                                    elif not "llvm" in list_tokens[t_index] and ("load" in list_tokens[:t_index] or "call" in list_tokens[:t_index]):
                                                            #特殊的自定义变量
                                                            #变量名映射
                                                        if list_tokens[t_index] in variables:
                                                            list_tokens[t_index] = "variable_"+str(variables.index(list_tokens[t_index]))
                                                        else:
                                                            variables.append(list_tokens[t_index])
                                                            list_tokens[t_index] = "variable_"+str(len(variables)-1)
                                        
                                            slice_corpus = slice_corpus + list_tokens
                
                                            linenum_index += 1
                                            slice_linenum.append(token_index)   #记录每一行的起始token
                                            #如果是漏洞行，记录index，用于后续生成漏洞位置矩阵
                                            if linenum_index in vlinenumlists:
                                                slice_vlinenum.append(token_index)    #记录漏洞行句首token在整个序列中的索引值

                                            #记录已经处理的词的数量
                                            token_index = token_index + len(list_tokens)
                                    
                                        #切片调用函数的去重和处理
                                        slice_func = list(set(slice_func))
                                        if slice_func == []:
                                            #对于Bad/Good类testcase可能只有main函数，此处添加main函数保证该testcase参与函数级指标的统计
                                            slice_func = ['main']
										
										#在CORPUSPATH路径下保存testcase的语料文件
                                        folder_path = os.path.join(corpuspath, category_1+'+'+category_3)
                                        savefilepath = os.path.join(folder_path, fourfocus+'_'+filename[:-3]+'.pkl')
                                        if category_1+'+'+category_3 not in os.listdir(corpuspath):    #如果路径不存在则创建路径
                                            os.mkdir(folder_path)
                                            os.chmod(folder_path, stat.S_IRWXO)#更改目录权限（读写）
                                        f = open(savefilepath, 'wb')                  #新创建文件
                                        pickle.dump([slice_corpus ,slice_linenum, slice_vlinenum, slice_func], f)
                                        f.close()
                                    else:
                                        print('\n',filename)

if __name__ == '__main__':
    
    #读取数据及保存数据的路径
    SLICEPATH = './data/NVD/data_source/'
    LABELPATH = './data/NVD/label_source/'  #标签数据路径
    CORPUSPATH = './data/NVD/corpus_NVD/'   #语料库保存路径                                                                                                                                                                                                                                                                

    #处理数据并形成词库
    get_sentences(SLICEPATH, LABELPATH, CORPUSPATH)

    print('\nsuccess!')
